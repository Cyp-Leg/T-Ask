const config = {
    WELCOME_STATE: "WELCOME",
    LOGIN_STATE: "LOGIN"
}

module.exports = config;