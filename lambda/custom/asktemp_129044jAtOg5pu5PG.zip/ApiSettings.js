let ApiSettings = {
}

module.exports = ApiSettings;